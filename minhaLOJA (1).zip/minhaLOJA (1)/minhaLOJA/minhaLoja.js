const Toast = Swal.mixin({
    toast: true,
    showConfirmButton: false,
    timer: 2000,
    timerProgressBar: true,
})

function editar(elem){
    
    const div = document.querySelectorAll(".divEditar");
    
    for (let i = 0; i < div.length; i++) {
        
        const element = div[i];

        if(element.attributes.id.value==elem){

            console.log($("#saborProduto",element))
            if($("#saborProduto",element).length==0){

                const select = element.querySelectorAll("select")

                const salvar = element.querySelector(".botaoSalvar")

                salvar.style.display='block'
                // element.querySelector(".tamanhos").style.display='flex'

                const excluir = '<i class="bi bi-x" onclick="closeChip(this)"></i> '

                $(".divEditar[id='"+elem+"']").find(".chipSabor").each(function(){
                    
                    $(this).append(excluir)
                
                })

                $(".divEditar[id='"+elem+"']").find("#saboresProdutosChips").append('<input type="text" id="saborProduto" onkeypress="addChip(this,event)"/>')


                for (let i = 0; i < select.length; i++) {
                    const element2 = select[i];
                    element2.disabled=false
                    
                }
            }
        }
    }  
}



$("option").on("click",function(elem){

    if($(elem.target).attr("option selected")){
    
        $(elem.target).removeAttr("selected")

    }
    else{

        $(elem.target).attr("selected",true)

    }
})

function salvar(elem){

    const div = document.querySelectorAll(".divEditar");

    for (let i = 0; i < div.length; i++) {

        const element = div[i];

        if(element.attributes.id.value==elem){

            const select = element.querySelectorAll("select")

            const salvar = element.querySelector(".botaoSalvar")

            salvar.style.display='none'

            for (let i = 0; i < select.length; i++){

                const element2 = select[i];
                element2.disabled=true
                
            }

            for (let i = 0; i < loja.length; i++) {
 
                if(loja[i].id==elem){

                    loja[i].sabor = $(".chipSabor",element).map(function(){return $(this).text()}).toArray()

                    loja[i].tamanho = $("#tamanhoProduto",element).val()

                    carregarProdutos()
                    break;
                }  
            }
        }
    }
     // $(".tamanhos").hide()
}

function excluirProduto(elem){

    for (let i = 0; i < loja.length; i++) {

        const element = loja[i];

        if(element.id==elem){
            loja.splice(i, 1);
            carregarProdutos()
            // $(".tamanhos").hide()
            break;
        }  
    }
}

function contemTamanho(array,tamanho){

    var ret =  (array?.indexOf(tamanho) != undefined && array?.indexOf(tamanho) != -1 ) ? 
                'selected' 
                :
                'multiple ';  
    return ret;
}

function carregarProdutos(){

    var conteudoPrincipal = document.getElementById("divProdutos");
    $("#divProdutos").children(".divEditar").remove()
    var htmlProdutos = "";

    for(var i=0; i<loja.length; i++){
        var ProdutoAtual = loja[i];
        var cartaoProduto = 
                    `
                    <div class="row m-3 divEditar" id="${ProdutoAtual.id}">
                    <div class="col-sm-2 col-sm-2">
                        <img src="${ProdutoAtual.arquivo}" class="imgMain" alt="Vitamina de Frutas">
                    </div>
                    <div class="col-sm-4 col-6">
                        <div class="row">
                            <div class="col-sm-12">
                                <span class="spProdutos">
                                    ${ProdutoAtual.nome}
                                </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <span>Sabores:</span>
                                <div id="saboresProdutosChips" name="saboresProdutosChips">
                                ${ProdutoAtual.sabor.reduce(
                                    (accumulator, currentValue) => accumulator + "<span class='chipSabor'>"+currentValue+"</span>",
                                    ""
                                )}
                                </div>
                            </div>
                        </div>
                        <div class="row tamanhos">
                            <div class="col-sm-12">
                                <span>tamanhos:</span>
                                <select class="selecionaSabores" class="mt-1 custom-s" id="tamanhoProduto"
                                    multiple disabled>
                                    <optgroup>
                                        <option value="Pequena" ${contemTamanho(ProdutoAtual.tamanho,('Pequena'))}>Pequena (250ml)</option>
                                        <option value="Média" ${contemTamanho(ProdutoAtual.tamanho,('Média'))}>Média (500ml)</option>
                                        <option value="Grande" ${contemTamanho(ProdutoAtual.tamanho,('Grande'))}>Grande (700ml)</option>
                                    </optgroup>
                                </select>
                            </div>
                        </div>
                    </div> 
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoLixeira" onclick="excluirProduto(${ProdutoAtual.id})" title="Excluir"><i class="bi bi-trash icon-trash"></i></button>
                    </div>
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoEditar"  onclick="editar(${ProdutoAtual.id})" title="Editar"><i class="bi bi-pencil-square"></i></button>
                    </div>
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoSalvar"  style="display: none;" onclick="salvar(${ProdutoAtual.id})" title="Salvar"><i class="bi bi-check2-square"></i></button>
                    </div>
                </div>`;
                                          

        htmlProdutos += cartaoProduto;
        
    }
    conteudoPrincipal.innerHTML += htmlProdutos;  
    localStorage.setItem('produtos', JSON.stringify(loja));  
    localStorage.setItem("id_max", id_produto);

    focarInput()

}

function limparModal(){
    var modal = document.getElementById("adicionarProduto");
    var bootstrapModal = bootstrap.Modal.getInstance(modal);
    bootstrapModal.hide();
}

function limparFormulario(){
    $('.modal').find('.chipSabor').remove()
    $('.modal').find('#nomeProduto').val("")
    $('.modal').find('#imgProduto').val("")
    $('.modal').find('#inputname').remove()

}

function retornaSabores(){ 

    var a = new Array()

    $(".modal .chipSabor").each(function(){
    
        a.push($(this).text())
        
    })

    return a;

}

function adicionarProduto(){

    var nome = document.getElementById("nomeProduto").value;
    var sabor = retornaSabores();
    var tamanho = contemTamanho();
    var arquivo = document.getElementById("imgProduto").files[0];
    var url;

    var reader = new FileReader()

    reader.readAsDataURL(arquivo)

    reader.addEventListener('load', () => {

        url = reader.result;

        console.log(url)

        var id = id_produto++;
         id++;
    
        let novoProduto = {
            "nome" : nome,
            "sabor" : sabor,
            "tamanho" : tamanho,
            "arquivo"  : url,
            "id"    : id
        }
    
        loja.push(novoProduto);
        localStorage.setItem('produtos', JSON.stringify(loja));
        localStorage.setItem("id_max", id);
        limparModal()
        limparFormulario()
        carregarProdutos()

        // $(".tamanhos").hide()
    });
}

function salvarProduto(){

  var form = document.getElementById("formAdicionar");
  var valid = true;
  
  if (!form.checkValidity()) {
    Swal.fire({
        icon: 'error',
        title: 'CAMPO VAZIO',
        text: 'Campos obrigatórios não preenchidos!',
    })

     form.classList.add('was-validated')
  } 
  
  if(valid)
    adicionarProduto();
}

function addChip(elem,event){

    if (event.which == 13) {

        var input = elem.value;

        var obj = document.createElement('span')
        obj.className='chipSabor'
        obj.innerHTML=` ${input}<i class="bi bi-x" onclick="closeChip(this)"></i> `
        
        if(input == ""|| input == null){
            
            Toast.fire({
            icon: 'error',
            title: 'Valor vazio'
            })
        
        } else{
            elem.parentNode.insertBefore(obj,elem);
            elem.value=""
        }
    }
}

function closeChip(elem){

    elem.parentNode.remove()

}

var loja = JSON.parse(localStorage.getItem('produtos'));
var id_produto = JSON.parse(localStorage.getItem("id_max"))

if(!loja || loja==null){
    console.log(loja)
    loja = new Array({
        nome : 'Suco Natural', sabor: ['Laranja', 'Maracujá', 'Maçã', 'Uva'], tamanho: ['100ml', '250ml', '350ml'], arquivo: 'img/vitamina-de-frutas-2.jpg', id: '0',edicao:false}
        ,{ 
        nome: 'Bombons', sabor: ['Morango', 'Maracujá', 'Chocolate', 'Amargo'], arquivo: 'img/bombons-g.jpg', id: '1',edicao:false},
        { 
        nome: 'Bolo de Pote', sabor: ['Doce de Leite', 'Chocolate', 'Ninho', 'Morango'], tamanho: ['Pequeno', 'Médio', 'Grande'], arquivo: 'img/sabores-de-bolo-no-pote-mais-vendidos-1200x800.jpg', id: '2',edicao:false},
        { 
        nome: 'Coxinha', sabor: ['Frango', 'Frango c/ Catupiry', 'Queijo', 'Calabresa'], tamanho: ['Pequena', 'Média', 'Grande'], arquivo: 'img/coxinha-4161592_1280.jpg', id: '3',edicao:false
    });
}

id_produto = ( id_produto == null ? (Number(loja.length)): id_produto);

$(document).ready(function(){

    carregarProdutos();
    // $(".tamanhos").hide()

})

function focarInput(){

    $("#saboresProdutosChips,.chipSabor").on("click",function(){

        console.log("teste")
        $(this).find('#saborProduto').trigger( "focus" );
    
    })

}

var $input    = document.getElementById('imgProduto'),
$fileName = document.getElementById('inputname');

$input.addEventListener('change', function(){
    $fileName.textContent = this.value;

});