const reader = new FileReader()

function editar(elem){

    const div = document.querySelectorAll(".divEditar");
    
    for (let i = 0; i < div.length; i++) {
        
        const element = div[i];

        if(element.attributes.id.value==elem){

            const select = element.querySelectorAll("select")

            const salvar = element.querySelector(".botaoSalvar")

            salvar.style.display='block'

            for (let i = 0; i < select.length; i++) {
                const element2 = select[i];
                element2.disabled=false

                var obj = document.createElement('span')
                obj.className='chipSabor'
                obj.innerHTML=` ${input}<i class="bi bi-x" onclick="closeChip(this)"></i> `
    
                document.querySelectorAll(".modal #saboresProdutosChips")[elem].insertBefore(obj,elem);
                
            }
        }
    }
}

$("option").on("click",function(elem){

    if($(elem.target).attr("option selected")){
    
        $(elem.target).removeAttr("selected")

    }
    else{

        $(elem.target).attr("selected",true)

    }
})

function salvar(elem){

    const div = document.querySelectorAll(".divEditar");
    
    for (let i = 0; i < div.length; i++) {
        
        const element = div[i];

        if(element.attributes.id.value==elem){

            const select = element.querySelectorAll("select")

            const salvar = element.querySelector(".botaoSalvar")

            salvar.style.display='none'

            for (let i = 0; i < select.length; i++){

                const element2 = select[i];
                element2.disabled=true
                
            }

            for (let i = 0; i < loja.length; i++) {

                const l_element = loja[i];
        
                if(l_element.id==elem){
                    l_element.sabores = $(".chipSabor",element).map(function(){return $(this).text()})
                    l_element.tamanho = element.querySelector(".selecionaSabores").value
                    carregarProdutos()
                    break;
                }  
            }
        }
    }
}

function excluirProduto(elem){

    var array = document.querySelectorAll(".divEditar")

    for (let i = 0; i < loja.length; i++) {

        const element = loja[i];

        if(element.id==elem){
            loja.splice(i, 1);
            carregarProdutos()
            break;
        }  
    }
}

function contemTamanho(array,tamanho){

    var ret =  (array?.indexOf(tamanho) != undefined && array?.indexOf(tamanho) != -1 ) ? 
                'selected' 
                :
                'multiple ';  
    return ret;
}

function carregarProdutos(){

    var conteudoPrincipal = document.getElementById("divProdutos");
    $("#divProdutos").children(".divEditar").remove()
    var htmlProdutos = "";

    for(var i=0; i<loja.length; i++){
        var ProdutoAtual = loja[i];
        var cartaoProduto = 
                    `<div class="row m-3 divEditar" id="${ProdutoAtual.id}">
                    <div class="col-sm-2 col-sm-2">
                        <img src="${ProdutoAtual.arquivo}" class="imgMain" alt="Vitamina de Frutas">
                    </div>
                    <div class="col-sm-4 col-6">
                        <div class="row">
                            <div class="col-sm-12">
                                <span class="spProdutos">
                                    ${ProdutoAtual.nome}
                                </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <span>Sabores:</span>
                                <div id="saboresProdutosChips" name="saboresProdutosChips">
                                ${ProdutoAtual.sabor.reduce(
                                    (accumulator, currentValue) => accumulator + "<span class='chipSabor'>"+currentValue+"</span>",
                                    ""
                                )}
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <span>tamanhos:</span>
                                <select class="selecionaSabores" class="mt-1 custom-s" id="tamanhoProduto"
                                    multiple disabled>
                                    <optgroup label="Por Grandeza">
                                        <option value="Pequena" ${contemTamanho(ProdutoAtual.tamanho,('Pequena'))}>Pequena</option>
                                        <option value="Média" ${contemTamanho(ProdutoAtual.tamanho,('Média'))}>Média</option>
                                        <option value="Grande" ${contemTamanho(ProdutoAtual.tamanho,('Grande'))}>Grande</option>
                                    </optgroup>
                                    
                                    <optgroup label="Por Medida">
                                        <option value="100ml" ${contemTamanho(ProdutoAtual.tamanho,('100ml'))}>100ml</option>
                                        <option value="200ml" ${contemTamanho(ProdutoAtual.tamanho,('200ml'))}>250ml</option>
                                        <option value="300ml" ${contemTamanho(ProdutoAtual.tamanho,('300ml'))}>350ml</option>
                                    </optgroup>

                                </select>
                            </div>
                        </div>
                    </div> 
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoLixeira" onclick="excluirProduto(${ProdutoAtual.id})" title="Excluir"><i class="bi bi-trash icon-trash"></i></button>
                    </div>
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoEditar"  onclick="editar(${ProdutoAtual.id})" title="Editar"><i class="bi bi-pencil-square"></i></button>
                    </div>
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoSalvar"  style="display: none;" onclick="salvar(${ProdutoAtual.id})" title="Salvar"><i class="bi bi-check2-square"></i></button>
                    </div>
                </div>`;
        htmlProdutos += cartaoProduto;
    }
    conteudoPrincipal.innerHTML += htmlProdutos;  
    localStorage.setItem('produtos', JSON.stringify(loja));  
    localStorage.setItem("id_max", id_produto);

}
function limparFormulario(){

    document.getElementById("nomeProduto").value = "";
    document.getElementById("saborProduto").value = "";
    document.getElementById("tamanhoProduto").value = "";
    document.getElementById("imgProduto").value = "";

}

function limparModal(){
    var modal = document.getElementById("adicionarProduto");
    var bootstrapModal = bootstrap.Modal.getInstance(modal);
    bootstrapModal.hide();
    limparFormulario()   

}

function retornaSabores(){ 

    var a = new Array()

    $(".modal .chipSabor").each(function(){
    
        a.push($(this).text())
        
    })

    return a;

}

function adicionarProduto(){

    var nome = document.getElementById("nomeProduto").value;
    var sabor = retornaSabores();
    var tamanho = contemTamanho();
    var arquivo = document.getElementById("imgProduto").files[0];
    var url;
    reader.readAsDataURL(arquivo)

    reader.addEventListener('load', () => {

        url = reader.result;

        console.log(url)

        var id = id_produto;
        id_produto++;
    
        let novoProduto = {
            "nome" : nome,
            "sabor" : sabor,
            "tamanho" : tamanho,
            "arquivo"  : url,
            "id"    : id
        }
    
        loja.push(novoProduto);
        localStorage.setItem('produtos', JSON.stringify(loja));
        localStorage.setItem("id_max", id_produto);
        limparModal()
        limparFormulario()
        carregarProdutos()

    });
}

function salvarProduto(){

  var form = document.getElementById("divProdutos")
  var valid = true;
  
  if (!form.checkValidity()) {
    valid = false;
  }
  form.classList.add('was-validated')
  
  if(valid)
    adicionarProduto(loja);

}

function addChip(elem,event){

    if (event.which == 13) {

        var input = elem.value;

        var obj = document.createElement('span')
        obj.className='chipSabor'
        obj.innerHTML=` ${input}<i class="bi bi-x" onclick="closeChip(this)"></i> `
    
        document.querySelectorAll(".modal #saboresProdutosChips")[0].insertBefore(obj,elem);
    
        elem.value=""

    }
}

function closeChip(elem){

    elem.parentNode.remove()

}

var loja = JSON.parse(localStorage.getItem('produtos'));
var id_produto = JSON.parse(localStorage.getItem("id_max"))

if(!loja || loja==null){
    console.log(loja)
    loja = new Array({
        nome : 'Suco Natural', sabor: ['Laranja', 'Maracujá', 'Maçã', 'Uva'], tamanho: ['100ml', '250ml', '350ml'], arquivo: 'img/vitamina-de-frutas-2.jpg', id: '0'}
        ,{ 
        nome: 'Bombons', sabor: ['Morango', 'Maracujá', 'Chocolate', 'Amargo'], arquivo: 'img/bombons-g.jpg', id: '1'},
        { 
        nome: 'Bolo de Pote', sabor: ['Doce de Leite', 'Chocolate', 'Ninho', 'Morango'], tamanho: ['Pequeno', 'Médio', 'Grande'], arquivo: 'img/sabores-de-bolo-no-pote-mais-vendidos-1200x800.jpg', id: '2'},
        { 
        nome: 'Coxinha', sabor: ['Frango', 'Frango c/ Catupiry', 'Queijo', 'Calabresa'], tamanho: ['Pequena', 'Média', 'Grande'], arquivo: 'img/coxinha-4161592_1280.jpg', id: '3'
    });
}

id_produto = ( id_produto == null ? (Number(loja.length)): id_produto);

$(document).ready(function(){

    carregarProdutos();

})




