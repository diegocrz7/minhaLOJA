function editar(elem){

    const div = document.querySelectorAll(".divEditar");
    
    for (let i = 0; i < div.length; i++) {
        
        const element = div[i];

        if(element.attributes.id.value==elem){

            const select = element.querySelectorAll("select")

            const salvar = element.querySelector(".botaoSalvar")

            salvar.style.display='block'

            for (let i = 0; i < select.length; i++) {

                const element2 = select[i];
                element2.disabled=false
                
            }
        }
    }
}

function salvar(elem){

    const div = document.querySelectorAll(".divEditar");
    
    for (let i = 0; i < div.length; i++) {
        
        const element = div[i];

        if(element.attributes.id.value==elem){

            const select = element.querySelectorAll("select")

            const salvar = element.querySelector(".botaoSalvar")

            salvar.style.display='none'

            for (let i = 0; i < select.length; i++) {

                const element2 = select[i];
                element2.disabled=true
                
            }

        }

    }
}

function excluirProduto(elem){

    var array = document.querySelectorAll(".divEditar")

    for (let i = 0; i < array.length; i++) {

        const element = array[i];

        if(element.attributes.id.value==elem){
            element.remove()
            break;
        }  
        
    }
    
}
function carregarProdutos(loja){
    localStorage.getItemItem('produtos', JSON.stringify(produtos));
    var conteudoPrincipal = document.getElementById("divProdutos");
    var htmlProdutos = "";
    console.log('loja',loja)
    console.log('loja.length',loja.length)
    for(var i=0; i<loja.length; i++){
        var ProdutoAtual = loja[i];
        var cartaoProduto = 
                    `<div class="row m-3 divEditar" id="${ProdutoAtual.id}">
                    <div class="col-sm-2 col-sm-2">
                        <img src="${ProdutoAtual.foto}" class="imgMain" alt="Vitamina de Frutas">
                    </div>
                    <div class="col-sm-4 col-6">
                        <div class="row">
                            <div class="col-sm-12">
                                <span class="spProdutos">
                                    ${ProdutoAtual.nome}
                                </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <span>sabores:</span>
                                <select disabled class="selecionaSabores" multiple>
                                    <option value="item1">${ProdutoAtual.sabor}</option>
                                    <option value="item2">${ProdutoAtual.sabor}</option>
                                    <option value="item3">${ProdutoAtual.sabor}</option>
                                    <option value="item4">${ProdutoAtual.sabor}</option>
                                </select disabled>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <span>tamanhos:</span>
                                <select disabled class="selecionaSabores" class="mt-1 custom-s" multiple>
                                    <option value="item1">${ProdutoAtual.tamanho}</option>
                                    <option value="item2">${ProdutoAtual.tamanho}</option>
                                    <option value="item3">${ProdutoAtual.tamanho}</option>
                                </select>
                            </div>
                        </div>
                    </div> 
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoLixeira" onclick="excluirProduto(${ProdutoAtual.id})" title="Excluir"><i class="bi bi-trash icon-trash"></i></button>
                    </div>
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoEditar"  onclick="editar(${ProdutoAtual.id})" title="Editar"><i class="bi bi-pencil-square"></i></button>
                    </div>
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoSalvar"  style="display: none;" onclick="salvar(${ProdutoAtual.id})" title="Salvar"><i class="bi bi-check2-square"></i></button>
                    </div>
                </div>`;
        htmlProdutos += cartaoProduto;
    }
    conteudoPrincipal.innerHTML += htmlProdutos;    
}


function limparModal(){
    var modal = document.getElementById("adicionarProduto");
    var bootstrapModal = bootstrap.Modal.getInstance(modal);
    bootstrapModal.hide();   
}

function adicionarProduto(){

    var nome = document.getElementById("nomeProduto").value;
    var sabor = document.getElementById("saborProduto").value;
    var tamanho = document.getElementById("tamanhoProduto").value;
    var arquivo = document.getElementById("imgProduto").value;
    var id = id_produto;
    id_produto++;
    
    arquivo = arquivo.split("\\")[2];

    let novoProduto = {
        "nome" : nome,
        "sabor" : sabor,
        "tamanho" : tamanho,
        "foto"  : arquivo,
        "id"    : id
    }

    loja.push(novoProduto);
    localStorage.setItem("produtos", JSON.stringify(loja));
    localStorage.setItem("id_max", id_produto);
    limparModal()
    carregarProdutos(loja)

}

function salvarProduto(){

  var form = document.getElementById("divProdutos")
  var valid = true;
  
  if (!form.checkValidity()) {
    valid = false;
  }
  form.classList.add('was-validated')
  
  if(valid)
    adicionarProduto(loja);

}

function addChip(elem,event){

    if (event.which == 13) {

        var input = elem.value;

        var obj = document.createElement('span')
        obj.className='chipSabor'
        obj.innerHTML=` ${input}<i class="bi bi-x" onclick="closeChip(this)"></i> `
    
        document.getElementById("saboresProdutosChips").insertBefore(obj,elem);
    
        elem.value=""

    }

}

function closeChip(elem){

    elem.parentNode.remove()

}

var loja = localStorage.setItem('produtos', JSON.stringify(produtos));
var id_produto = JSON.parse(localStorage.getItem("id_max"))
id_produto = id_produto == null ? 0 : id_produto;S

if(!loja){
    console.log(loja)
    loja = new Array()
}


$(document).ready(function(){

    carregarProdutos(loja);

})

var produtos = {
                    nome : 'Suco Natural', sabor: 'Laranja, Maracujá, Maçã, Uva', tamanho: '100ml, 250ml, 350ml', arquivo: 'img/vitamina-de-frutas-2.jpg', id: '0', 
                    nome: 'Bombons', sabor: 'Morango, Maracujá, Chocolate, Amargo', arquivo: 'img/bombons-g.jpg', id: '1', 
                    nome: 'Bolo de Pote', sabor: 'Doce de Leite, Chocolate, Ninho, Morango', tamanho: 'Pequeno, Médio, Grande', arquivo: 'img/sabores-de-bolo-no-pote-mais-vendidos-1200x800.jpg', id: '2', 
                    nome: 'Coxinha', sabor: 'Frango, Frango c/ Catupiry, Queijo, Calabresa', tamanho: 'Pequena, Média, Grande', arquivo: 'img/coxinha-4161592_1280.jpg', id: '3'
                };




