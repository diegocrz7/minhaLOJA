function editar(elem){

    const div = document.querySelectorAll(".divEditar");
    
    for (let i = 0; i < div.length; i++) {
        
        const element = div[i];

        if(element.attributes.id.value==elem){

            const select = element.querySelectorAll("select")

            const salvar = element.querySelector(".botaoSalvar")

            salvar.style.display='block'

            for (let i = 0; i < select.length; i++) {

                const element2 = select[i];
                element2.disabled=false
                
            }

        }

    }
}

function salvar(elem){

    const div = document.querySelectorAll(".divEditar");
    
    for (let i = 0; i < div.length; i++) {
        
        const element = div[i];

        if(element.attributes.id.value==elem){

            const select = element.querySelectorAll("select")

            const salvar = element.querySelector(".botaoSalvar")

            salvar.style.display='none'

            for (let i = 0; i < select.length; i++) {

                const element2 = select[i];
                element2.disabled=true
                
            }

        }

    }
}

function excluirProduto(elem){

    var array = document.querySelectorAll(".divEditar")

    for (let i = 0; i < array.length; i++) {

        const element = array[i];

        if(element.attributes.id.value==elem){
            element.remove()
            break;
        }  
        
    }
    
    
}

function adicionarProduto(){


        
}


