function editar(elem){

    const div = document.querySelectorAll(".divEditar");
    
    for (let i = 0; i < div.length; i++) {
        
        const element = div[i];

        if(element.attributes.id.value==elem){

            const select = element.querySelectorAll("select")

            const salvar = element.querySelector(".botaoSalvar")

            salvar.style.display='block'

            for (let i = 0; i < select.length; i++) {

                const element2 = select[i];
                element2.disabled=false
                
            }

        }

    }
}

function salvar(elem){

    const div = document.querySelectorAll(".divEditar");
    
    for (let i = 0; i < div.length; i++) {
        
        const element = div[i];

        if(element.attributes.id.value==elem){

            const select = element.querySelectorAll("select")

            const salvar = element.querySelector(".botaoSalvar")

            salvar.style.display='none'

            for (let i = 0; i < select.length; i++) {

                const element2 = select[i];
                element2.disabled=true
                
            }

        }

    }
}

function excluirProduto(elem){

    var array = document.querySelectorAll(".divEditar")

    for (let i = 0; i < array.length; i++) {

        const element = array[i];

        if(element.attributes.id.value==elem){
            element.remove()
            break;
        }  
        
    }
    
}
function carregarProdutos(loja){
    var conteudoPrincipal = document.getElementById("mainCenter");
    var htmlProdutos = "";
    for(let i=0; i<loja.length; i++){
        var ProdutoAtual = loja[i];
        var cartaoProduto = 
                    `<div class="row m-3 divEditar" id="6">
                    <div class="col-sm-2 col-sm-2">
                        <img src="${ProdutoAtual.foto}" class="imgMain" alt="Vitamina de Frutas">
                    </div>
                    <div class="col-sm-4 col-6">
                        <div class="row">
                            <div class="col-sm-12">
                                <span class="spProdutos">
                                    ${ProdutoAtual.nome}
                                </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <span>sabores:</span>
                                <select disabled class="selecionaSabores">
                                    <option value="item1">${ProdutoAtual.sabor}</option>
                                    <option value="item2">${ProdutoAtual.sabor}</option>
                                    <option value="item3">${ProdutoAtual.sabor}</option>
                                    <option value="item4">${ProdutoAtual.sabor}</option>
                                </select disabled>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <span>tamanhos:</span>
                                <select disabled class="selecionaSabores" class="mt-1 custom-s">
                                    <option value="item1">100ml</option>
                                    <option value="item2">250ml</option>
                                    <option value="item3">350ml</option>
                                </select>
                            </div>
                        </div>
                    </div> 
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoLixeira" onclick="excluirProduto(6)" title="Excluir"><i class="bi bi-trash icon-trash"></i></button>
                    </div>
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoEditar"  onclick="editar(6)" title="Editar"><i class="bi bi-pencil-square"></i></button>
                    </div>
                    <div class="col-sm-2 col-2">
                        <button type="button" class="botaoSalvar"  style="display: none;" onclick="salvar(6)" title="Salvar"><i class="bi bi-check2-square"></i></button>
                    </div>
                </div>`;
        htmlProdutos += cartaoProduto;
    }
    conteudoPrincipal.innerHTML += htmlProdutos;    
}

function adicionarProduto(){

    var nome = document.getElementById("nomeProduto").value;
    var sabor = document.getElementById("saborProduto").value;
    var tamanho = document.getElementById("tamanhoProduto").value;
    var arquivo = document.getElementById("imgProduto").value;
    
    arquivo = arquivo.split("\\")[2];

    let novoProduto = {
        "nome" : nome,
        "sabor" : sabor,
        "tamanho" : tamanho,
        "foto"  : arquivo
    }
    loja.push(novoProduto);
    localStorage.setItem("produtos", JSON.stringify(loja));    
}

function salvarProduto(){

  var form = document.querySelector('#formAdicionar')
  var valid = true;
  
  if (!form.checkValidity()) {
    valid = false;
  }
  form.classList.add('was-validated')
  
  if(valid)
    adicionarProduto();

}

function addChip(elem,event){

    if (event.which == 13) {

        var input = elem.value

        var obj = document.createElement('span')
        obj.className='chipSabor'
        obj.innerHTML=` ${input}<i class="bi bi-x" onclick="closeChip(this)"></i> `
    
        document.getElementById("saboresProdutosChips").insertBefore(obj,elem);
    
        elem.value=""

    }

}

function closeChip(elem){

    elem.parentNode.remove()

}

window.onload = carregarProdutos();


var loja = JSON.parse(localStorage.getItem("produtos"))

if(!loja){
    loja = []
}




