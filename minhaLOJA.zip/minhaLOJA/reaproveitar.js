function adicionarProduto() {
    var nome = document.getElementById("nomeProduto").value;
    var sabor = document.getElementById("saborProduto").value;
    var tamanho = document.getElementById("tamanhoProduto").value;
    var arquivo = document.getElementById("imgProduto").value;

    arquivo = arquivo.split("\\")[2];

    let novoProduto = {
        "nome": nome,
        "sabor": sabor,
        "tamanho": tamanho,
        "foto": arquivo
    };

    var divProdutos = document.getElementById("mainCenter");
    var novoProdutoHTML = criarProdutoHTML(novoProduto);
    divProdutos.appendChild(novoProdutoHTML);

    // Limpar os campos de entrada após adicionar o produto
    document.getElementById("nomeProduto").value = "";
    document.getElementById("saborProduto").value = "";
    document.getElementById("tamanhoProduto").value = "";
    document.getElementById("imgProduto").value = "";

    // Fechar o modal após adicionar o produto
    var modal = document.getElementById("adicionarProduto");
    var bootstrapModal = bootstrap.Modal.getInstance(modal);
    bootstrapModal.hide();
}

function criarProdutoHTML(produto) {
    var divProduto = document.createElement("div");
    divProduto.className = "row m-3 divEditar";
    divProduto.id = produto.id;

    var divImagem = document.createElement("div");
    divImagem.className = "col-sm-2 col-2";

    var imagemProduto = document.createElement("img");
    imagemProduto.src = produto.foto;
    imagemProduto.className = "imgMain";
    imagemProduto.alt = "Foto do Produto";
    divImagem.appendChild(imagemProduto);

    var divInfo = document.createElement("div");
    divInfo.className = "col-sm-4 col-6";

    var divNome = document.createElement("div");
    divNome.className = "row";
    var spanNome = document.createElement("span");
    spanNome.className = "spProdutos";
    spanNome.textContent = produto.nome;
    divNome.appendChild(spanNome);
    divInfo.appendChild(divNome);

    var divSabores = document.createElement("div");
    divSabores.className = "row";
    var spanSabores = document.createElement("span");
    spanSabores.textContent = "Sabores:";
    divSabores.appendChild(spanSabores);
    var selectSabores = document.createElement("select");
    selectSabores.disabled = true;
    selectSabores.className = "selecionaSabores";
    var optionSabor = document.createElement("option");
    optionSabor.value = "item1";
    optionSabor.textContent = produto.sabor;
    selectSabores.appendChild(optionSabor);
    divSabores.appendChild(selectSabores);
    divInfo.appendChild(divSabores);

    var divTamanhos = document.createElement("div");
    divTamanhos.className = "row";
    var spanTamanhos = document.createElement("span");
    spanTamanhos.textContent = "Tamanhos:";
    divTamanhos.appendChild(spanTamanhos);
    var selectTamanhos = document.createElement("select");
    selectTamanhos.disabled = true;
    selectTamanhos.className = "selecionaSabores mt-1 custom-s";
    var optionTamanho = document.createElement("option");
    optionTamanho.value = "item1";
    optionTamanho.textContent = produto.tamanho;
    selectTamanhos.appendChild(optionTamanho);
    divTamanhos.appendChild(selectTamanhos);
    divInfo.appendChild(divTamanhos);

    var divLixeira = document.createElement("div");
    divLixeira.className = "col-sm-2 col-2";
    var buttonLixeira = document.createElement("button");
    buttonLixeira.type = "button";
    buttonLixeira.className = "botaoLixeira";
    buttonLixeira.title = "Excluir";
    buttonLixeira.onclick = function() {
        excluirProduto(produto.id);
    };
    var iconLixeira = document.createElement("i");
    iconLixeira.className = "bi bi-trash icon-trash";
    buttonLixeira.appendChild(iconLixeira);
    divLixeira.appendChild(buttonLixeira);

    var divEditar = document.createElement("div");
    divEditar.className = "col-sm-2 col-2";
    var buttonEditar = document.createElement("button");
    buttonEditar.type = "button";
    buttonEditar.className = "botaoEditar";
    buttonEditar.title = "Editar";
    buttonEditar.onclick = function() {
        editar(produto.id);
    };
    var iconEditar = document.createElement("i");
    iconEditar.className = "bi bi-pencil-square";
    buttonEditar.appendChild(iconEditar);
    divEditar.appendChild(buttonEditar);

    divProduto.appendChild(divImagem);
    divProduto.appendChild(divInfo);
    divProduto.appendChild(divLixeira);
    divProduto.appendChild(divEditar);

    return divProduto;
}
